#ifndef PASSWORD_PROTOCOL_H
#define PASSWORD_PROTOCOL_H

#define SERVER_ADDRESS "127.0.0.1" // Change to "passwdgen.uniba.it" for the real server
#define SERVER_PORT 12345
#define MAX_PASSWORD_LENGTH 32
#define MIN_PASSWORD_LENGTH 6
#define BUFFER_SIZE 256

// Types of passwords
#define TYPE_NUMERIC 'n'
#define TYPE_ALPHABETIC 'a'
#define TYPE_MIXED 'm'
#define TYPE_SECURE 's'
#define TYPE_UNAMBIGUOUS 'u'
#define TYPE_HELP 'h'
#define TYPE_QUIT 'q'

#endif
