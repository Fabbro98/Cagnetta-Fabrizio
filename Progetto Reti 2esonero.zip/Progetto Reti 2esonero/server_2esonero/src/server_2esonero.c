#if defined WIN32
#include <winsock.h>
#else
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#define closesocket close
#endif
#include <stdio.h>
#include <time.h>
#include "password_protocol.h"

#define NO_ERROR 0
void clearwinsock() {
#if defined WIN32
	WSACleanup();
#endif
}

// Function prototypes
void generate_numeric(char *buffer, int length);
void generate_alpha(char *buffer, int length);
void generate_mixed(char *buffer, int length);
void generate_secure(char *buffer, int length);
void generate_unambiguous(char *buffer, int length);

int main() {
   #if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data;
	int result = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (result != NO_ERROR) {
	       printf("Error at WSAStartup()\n");
	       return 0;
	}
    #endif

    int server_socket;
    struct sockaddr_in server_addr, client_addr;
    char buffer[BUFFER_SIZE];
    socklen_t client_len = sizeof(client_addr);

    srand(time(NULL));

    // Create UDP socket
    if ((server_socket = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Setup server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(SERVER_PORT);

    // Bind the socket
    if (bind(server_socket, (const struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    printf("Server listening on port %d...\n", SERVER_PORT);

    while (1) {
        memset(buffer, 0, BUFFER_SIZE);
        recvfrom(server_socket, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, &client_len);

        printf("New request from %s:%d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));

        char type;
        int length;
        if (sscanf(buffer, "%c %d", &type, &length) != 2 || length < MIN_PASSWORD_LENGTH || length > MAX_PASSWORD_LENGTH) {
            snprintf(buffer, BUFFER_SIZE, "Error: Invalid request or length.\n");
        } else {
            switch (type) {
                case TYPE_NUMERIC: generate_numeric(buffer, length); break;
                case TYPE_ALPHABETIC: generate_alpha(buffer, length); break;
                case TYPE_MIXED: generate_mixed(buffer, length); break;
                case TYPE_SECURE: generate_secure(buffer, length); break;
                case TYPE_UNAMBIGUOUS: generate_unambiguous(buffer, length); break;
                default: snprintf(buffer, BUFFER_SIZE, "Error: Unknown type.\n");
            }
        }

        // Send response
        sendto(server_socket, buffer, strlen(buffer), 0, (struct sockaddr *)&client_addr, client_len);
    }

    closesocket(server_socket);
    clearwinsock();
    return 0;
}

// Function definitions
void generate_numeric(char *buffer, int length) {
    for (int i = 0; i < length; ++i)
        buffer[i] = '0' + rand() % 10;
    buffer[length] = '\0';
}

void generate_alpha(char *buffer, int length) {
    for (int i = 0; i < length; ++i)
        buffer[i] = 'a' + rand() % 26;
    buffer[length] = '\0';
}

void generate_mixed(char *buffer, int length) {
    for (int i = 0; i < length; ++i)
        buffer[i] = rand() % 2 ? 'a' + rand() % 26 : '0' + rand() % 10;
    buffer[length] = '\0';
}

void generate_secure(char *buffer, int length) {
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()";
    for (int i = 0; i < length; ++i)
        buffer[i] = charset[rand() % (sizeof(charset) - 1)];
    buffer[length] = '\0';
}

void generate_unambiguous(char *buffer, int length) {
    const char charset[] = "abcdefghjkmnpqrtuvwxyACDEFGHJKLMNPQRTUVWXY34679";
    for (int i = 0; i < length; ++i)
        buffer[i] = charset[rand() % (sizeof(charset) - 1)];
    buffer[length] = '\0';
}

